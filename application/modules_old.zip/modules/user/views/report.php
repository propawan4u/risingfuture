<!-- Main Area Strat Here -->
<div class="col-md-9 border border-info mt-1 rounded-lg text-light px-md-3">
    <div class="row">
        <div class="border border-info mt-3 rounded-lg text-light px-md-3 ml-3 mb-3">
            <h1>Welcome to Rising Future</h1>
        </div>
    </div>
</div>
<!-- Main Area End Here -->
</div>
</div>
</div>
</section>
</body>

</html>